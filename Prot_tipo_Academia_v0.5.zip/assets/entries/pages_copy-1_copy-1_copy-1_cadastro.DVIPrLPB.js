import{j as t,d as m,g as u,r as o,a as h,b as l,i as n,R as g,c as f,P as x,e as v,f as b}from"../chunks/chunk-CWjc8hXk.js";import{j as y}from"../chunks/chunk-Bfhq2hnu.js";/* empty css                      */const i=void 0,w=[{id:"d7iPCiOwvRH_5rkT_3eSI"},{id:"KNJd875MzjVO28eTaZkMO",maxWidth:991},{id:"JipW_NkFOkbHKGdQeHpLE",maxWidth:767},{id:"YbIy4cZ5MyiBfIj_P7tpb",maxWidth:479}],j=void 0,P=[],A=[],R=e=>t.jsxs("body",{className:"w-element",children:[t.jsxs("section",{className:"w-element w-element-39",children:[t.jsx("div",{className:"w-element w-card-18",children:t.jsx(m,{className:"w-image w-image-5"})}),t.jsx("div",{className:"w-element w-card-19",children:t.jsx("h1",{className:"w-element w-h1-4",children:"SOFTWARE GA ACADEMIA"})})]}),t.jsxs("section",{className:"w-element w-section-9",children:[t.jsx("div",{className:"w-element w-card-21",children:t.jsx(y,{code:`<style>
.ga-tabela{width:100%;border-collapse:collapse;background:#fff;color:#12234a;font-family:Arial,sans-serif}
.ga-tabela th,.ga-tabela td{padding:10px 14px;text-align:left;border-bottom:1px solid #c4d0ea}
.ga-tabela th{background:#e3ebfb}
.ga-tabela .v{text-align:right}
.ga-tabela .m{font-weight:700;color:#12347a}
.ga-tabela .n{background:#e3ebfb;color:#12347a;padding:2px 10px;border-radius:12px;font-size:.8rem;font-weight:700}
.ga-tabela .p{background:#f55f00;color:#fff;padding:2px 10px;border-radius:12px;font-size:.8rem;font-weight:700}
.ga-tabela tfoot td{background:#e3ebfb;font-weight:700;border-top:2px solid #12347a}
</style>
<div style="overflow-x:auto">
<table class="ga-tabela">
<thead><tr><th>Matrícula</th><th>Aluno</th><th>Plano</th><th>Tipo</th><th class="v">Mensalidade</th></tr></thead>
<tbody>
<tr><td class="m">623</td><td>Ana Souza</td><td>Mensal</td><td><span class="n">Normal</span></td><td class="v">R$ 120,00</td></tr>
<tr><td class="m">703</td><td>Gustavo Alves</td><td>Mensal</td><td><span class="n">Normal</span></td><td class="v">R$ 120,00</td></tr>
<tr><td class="m">20</td><td>Helena Rocha</td><td>Mensal</td><td><span class="p">Premium</span></td><td class="v">R$ 180,00</td></tr>
<tr><td class="m">790</td><td>Igor Martins</td><td>Mensal</td><td><span class="p">Premium</span></td><td class="v">R$ 180,00</td></tr>
<tr><td class="m">192</td><td>Lucas Pereira</td><td>Trimestral</td><td><span class="n">Normal</span></td><td class="v">R$ 105,00</td></tr>
<tr><td class="m">250</td><td>Marina Duarte</td><td>Trimestral</td><td><span class="n">Normal</span></td><td class="v">R$ 105,00</td></tr>
<tr><td class="m">450</td><td>Olívia Teixeira</td><td>Trimestral</td><td><span class="p">Premium</span></td><td class="v">R$ 155,00</td></tr>
<tr><td class="m">503</td><td>Paulo Ribeiro</td><td>Trimestral</td><td><span class="p">Premium</span></td><td class="v">R$ 155,00</td></tr>
<tr><td class="m">302</td><td>Rafaela Gomes</td><td>Anual</td><td><span class="n">Normal</span></td><td class="v">R$ 75,00</td></tr>
<tr><td class="m">605</td><td>Samuel Cardoso</td><td>Anual</td><td><span class="n">Normal</span></td><td class="v">R$ 75,00</td></tr>
<tr><td class="m">157</td><td>Felipe Costa</td><td>Anual</td><td><span class="p">Premium</span></td><td class="v">R$ 120,00</td></tr>
<tr><td class="m">158</td><td>Tatiana Lopes</td><td>Anual</td><td><span class="p">Premium</span></td><td class="v">R$ 120,00</td></tr>
</tbody>
<tfoot><tr><td colspan="4">Total mensal (18 alunos)</td><td class="v">R$ 2.265,00</td></tr></tfoot>
</table>
</div>`,className:"w-html-embed w-html-embed-1"})}),t.jsx("div",{className:"w-element w-card-23",children:t.jsx(u,{href:"/copy-1/cadastro",className:"w-element w-element-42",children:"Retornar"})})]}),t.jsx("section",{className:"w-element w-section-10",children:t.jsx("div",{className:"w-element w-card-20",children:t.jsx("h3",{className:"w-element w-element-40",children:"GA ACADEMIA"})})})]}),S=e=>{const{origin:a,pathname:d,search:s}=new URL(e);return`${a}${d}${s}`},T=o.memo(({pageKey:e,system:a})=>t.jsx(R,{system:a},e),(e,a)=>e.pageKey===a.pageKey),N=({data:e})=>{const{system:a,resources:d,url:s,pageMeta:r}=e,c=S(s),p=o.useMemo(()=>({imageLoader:n,assetBaseUrl:l,assetUrlsByPath:h,resources:d,breakpoints:w,onError:console.error}),[d]);return t.jsxs(g.Provider,{value:p,children:[t.jsx(f.Provider,{value:s,children:t.jsx(T,{pageKey:c,system:a})}),t.jsx(x,{url:s,pageMeta:r,siteName:i,imageLoader:n,assetBaseUrl:l}),t.jsx(v,{children:r.title})]})},z=Object.freeze(Object.defineProperty({__proto__:null,default:N},Symbol.toStringTag,{value:"Module"})),$=({})=>t.jsxs(t.Fragment,{children:[i,j,P.map(e=>t.jsx("link",{rel:"preload",href:`${l}${e}`,as:"font",crossOrigin:"anonymous"},e)),A.map(e=>t.jsx("link",{rel:"preload",href:`${l}${e}`,as:"image"},e))]}),M=Object.freeze(Object.defineProperty({__proto__:null,Head:$},Symbol.toStringTag,{value:"Module"})),O={hasServerOnlyHook:{type:"computed",definedAtData:null,valueSerialized:{type:"js-serialized",value:!0}},isClientRuntimeLoaded:{type:"computed",definedAtData:null,valueSerialized:{type:"js-serialized",value:!0}},onBeforeRenderEnv:{type:"computed",definedAtData:null,valueSerialized:{type:"js-serialized",value:null}},dataEnv:{type:"computed",definedAtData:null,valueSerialized:{type:"js-serialized",value:{server:!0}}},guardEnv:{type:"computed",definedAtData:null,valueSerialized:{type:"js-serialized",value:null}},onRenderClient:{type:"standard",definedAtData:{filePathToShowToUser:"/renderer/+onRenderClient.tsx",fileExportPathToShowToUser:[]},valueSerialized:{type:"plus-file",exportValues:b}},Page:{type:"standard",definedAtData:{filePathToShowToUser:"/pages/copy-1/copy-1/copy-1/cadastro/+Page.tsx",fileExportPathToShowToUser:[]},valueSerialized:{type:"plus-file",exportValues:z}},Head:{type:"standard",definedAtData:{filePathToShowToUser:"/pages/copy-1/copy-1/copy-1/cadastro/+Head.tsx",fileExportPathToShowToUser:[]},valueSerialized:{type:"plus-file",exportValues:M}}};export{O as configValuesSerialized};
